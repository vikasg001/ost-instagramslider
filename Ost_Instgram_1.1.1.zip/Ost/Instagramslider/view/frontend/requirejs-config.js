var	config	=	{
		map:	{
				'*':	{
						slick:	'Ost_Instagramslider/js/slick'
				}
		}
};
