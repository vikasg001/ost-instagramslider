<?php
namespace Ost\Instagramslider\Helper;
use Magento\Framework\App\Config\ScopeConfigInterface;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{	
	
	
	 protected $scopeConfig;

	 public function __construct(  
			\Magento\Framework\App\Helper\Context $context,
			\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
			) 
			
			{
				parent::__construct($context);
				$this->_scopeConfig = $scopeConfig;
					
			}

	public function setText()
	{
		  $configData = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_title',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
			
	
	}
	
	public function getConfigData()
	{	
		
		$configData['instagramslider_status'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/enable',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_title'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_title',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_userid'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_userid',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_token'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_token',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_item'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_item',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_dimension'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_dimension',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_autoplay'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_autoplay',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_play_speed'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_play_speed',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_navigation'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_navigation',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_pagination'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_pagination',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_margin'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_margin',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		$configData['instagramslider_rewind'] = $this->_scopeConfig->getValue('instagram_section/instagram_general/instagramslider_rewind',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
		
				
		$data = '';
		if($configData['instagramslider_status'] == 1){
			
			 $url = "https://api.instagram.com/v1/users/".$configData['instagramslider_userid']."/media/recent?s=150&access_token=".$configData['instagramslider_token']."&count=".$configData['instagramslider_item'];
			
			$ch = curl_init($url); 

			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
			$json = curl_exec($ch); 
			curl_close($ch);
			$result = json_decode($json);
			
			$width='';
			
			switch($configData['instagramslider_dimension'])
			{
				case '1': 
					$width=50;  
					$width_height='50x50'; 
				break;
				case '2': 
					$width=100; 
					$width_height='100x100'; 
				break;
				case '3': 
					$width=150; 
					$width_height='150x150'; 
				break;
				case '4': 
					$width=200; 
					$width_height='200x200'; 
				break;
				case '5': 
					$width=350; 
					$width_height='350x350'; 
				break;
				case '6': 
					$width=640; 
					$width_height='640x640'; 
				break;
				case '7': 
					$width=1080; 
					$width_height='1080x1080'; 
				break;
				
			}
			
			
			foreach ($result->data as $post) {
			$data['images'][] = array(
					'title' => ($post->caption)? (($post->caption->text) ? $post->caption->text :'') : '',
					'link'  => $post->link,
					'image' => str_replace('s320x320','s'.$width_height,$post->images->low_resolution->url)
				);
			}
			$data['title'] = $configData['instagramslider_title'];
			$data['item'] = ($configData['instagramslider_item'] == '')?0:$configData['instagramslider_item'];
			$data['width'] = $width;
			$data['autoplay'] = ($configData['instagramslider_autoplay']==0)?"false":"true";
			$data['autoplayspeed'] = ($configData['instagramslider_play_speed']==0)?0:$configData['instagramslider_play_speed'];
			$data['status'] = $configData['instagramslider_status'];
			$data['navigation'] = ($configData['instagramslider_navigation']==0)?"false":"true";
			$data['pagination'] = ($configData['instagramslider_pagination']==0)?"false":"true";
			$data['rewindnav'] = ($configData['instagramslider_rewind']==0)?"false":"true";
			$data['margin']= ($configData['instagramslider_margin']== '')?10:$configData['instagramslider_margin'];
			
			return $data;
		}
		else
		{
			return ;	
		}
	}
}
