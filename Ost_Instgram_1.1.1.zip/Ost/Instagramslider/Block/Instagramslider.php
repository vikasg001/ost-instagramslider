<?php
namespace Ost\Instagramslider\Block;

class Instagramslider extends \Magento\Framework\View\Element\Template
{
    
    public function __construct(\Magento\Framework\View\Element\Template\Context $context,\Ost\Instagramslider\Helper\Data $dataHelper)
	{
		parent::__construct($context);
		$this->_dataHelper = $dataHelper;
	}
    
    public function getTitle()
    {
		
		$html = $this->_dataHelper->getConfigData();
        return $html;
    }
    
    
    
}
