<?php
namespace  Ost\Instagramslider\Model;

class Dimension implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
 
        return [
            ['value' => 1, 'label' => __('50x50')],
            ['value' => 2, 'label' => __('100x100')],
            ['value' => 3, 'label' => __('150x150')],
            ['value' => 4, 'label' => __('150x150')],
            ['value' => 5, 'label' => __('200x200')],
            ['value' => 6, 'label' => __('350x350')],
            ['value' => 7, 'label' => __('640x640')],
            ['value' => 8, 'label' => __('1080x1080')]
        ];
    }
    
    public function toArray()
    {
 
        return [
            [1 => __('50x50')],
            [2 => __('100x100')],
            [3 => __('150x150')],
            [4 => __('150x150')],
            [5 => __('200x200')],
            [6 => __('350x350')],
            [7 => __('640x640')],
            [8 => __('1080x1080')]
        ];
    }
    
}

